import React from 'react';

function Footer(props) {
    return (
        <div>
         <h4><b>all rights reserved</b></h4> 
        </div>
    );
}

export default Footer;